focuses on building systems that are reliable, interpretable, and responsible. The goal is to align [[What is AI?|AI]] with societal values, legal frameworks, and ethical standards. 

The key issues are as follows:
1. Fairness and bias:
	- AI systems must avoid discrimination and ensure fair treatment across all demographics.
	- Example: Addressing biases in datasets to prevent AI models from reinforcing existing societal inequalities.
2. Explainability and transparency:
	- Models should provide human-understandable explanations for their decisions.
	- Transparent systems allow stakeholders to inspect how decisions are made, enabling accountability. This is for example in discussion in regards to black box trading models.
	- Clear versioning of models.
3. Safety and robustness
	- AI systems should function reliably under diverse conditions, including adversarial attacks or unexpected inputs
	 - Adversarial attacks are crafted inputs, such as introducing slight noise to trick classifiers or fake biometric data like fingerprints or voices
4. Privacy
	- User data must be protected through anonymisation techniques and secure data storage. 
	- Adherence to regulations like GDPR
5. Accountability
	- Clear accountability structures ensure that entities deploying AI systems are responsible for their impacts.
	- This includes maintaining audit trails and documenting design decisions.

Intellectual property (IP) in AI raises complex legal and ethical questions. AI-generated models and works challenge traditional notions of copyright. Different models could converge to become similar or the same during training. Conversely, the same reference model could diverge into different models due to varying training data or hyperparameters. In both cases, the resulting models might still qualify as original work if their development process is well-documented.

There is also the question about copyright ownership of machine-generated work. For example, AI systems like AutoML can automatically generate models. Should the copyright belong to the programmer, the user of the AI system, or no one at all? In the EU and USA, AI derived works cannot be copyrighted as they lack human authorship. In countries like India, Ireland, and the UK it can be copyrighted by the programmer.