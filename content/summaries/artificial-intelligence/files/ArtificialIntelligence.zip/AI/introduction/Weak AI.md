---
lecture: "2"
---
Also called narrow AI, it refers to machines in the engineering sense. These are machines that appear to be intelligent, but only the well-defined tasks they're designed for. Their capabilities remain restricted compared to human intelligence.

