---
lecture: "2"
---
The experiment is a though experiment proposed by philosopher John Searle in 1980 to challenge the idea that computer programs can have a mind or consciousness, no matter how intelligently it might behave.  
**Setup**
A person who does not understand Chinese is locked inside a room. The person is given
1. A set of rules (in English) for manipulating Chinese characters
2. A large database of Chinese symbols
3. A method to match questions written in Chinese with appropriate responses, also written in Chinese
The person receives input in Chinese through a slot and outputs a response using the database.
**Argument**
From the outside, the system appears to understand Chinese because it produces coherent responses. Searle argues that this illustrates why computers, which manipulate symbols according to programmed rules, cannot truly understand the semantics behind the symbols they process. 
**Counterargument**
Critics of the experiment argue that, while the individual inside the room does not understand Chinese, the entire system (person + rules + database) does. 
