---
lecture: "2"
---
AI is about building intelligent machines that think and act rational. 
The logical follow-up is "What is intelligence?" Intelligence is the ability to acquire and apply knowledge and skills. This can be expanded to the following 2 skills:
1. The ability to learn or understand or to deal with new or trying solutions (this inherently requires reasoning)
2. The ability to apply knowledge to manipulate one's environment or to think abstractly as measured by objective criteria (such as tests)
A definition that can be more closely applied to artificial intelligence is to see intelligence as a measure of an [[Agents|agent]]'s ability to **achieve goals in a wide range environments**.

Generally speaking, we differentiate between [[Strong AI]] and [[Weak AI]].

The field of AI is very broad. We're focusing on [[Machine Learning|machine learning]]. 

![[ai_disciplines.png]]

