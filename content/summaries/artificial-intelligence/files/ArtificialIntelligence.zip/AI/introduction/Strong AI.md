---
lecture: "2"
---
Also referred to as artificial general intelligence, it is AI in the philosophical sense. These are machines possessing generalized intelligence and capabilities on par with human cognition. That also means they are likely self-conscious.

Strong AI have open-ended abilities to learn, reason, and adapt to unfamiliar environments.

Some critics argue against the view that computer running the right program can genuinely have a mind, consciousness, or understanding. This is for example illustrated by the [[Chinese Room Thought Experiment]].
