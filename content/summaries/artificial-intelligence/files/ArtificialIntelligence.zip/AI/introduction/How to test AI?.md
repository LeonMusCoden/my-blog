---
lecture: "2"
---
A classic test is the Turing test, developed by Alan Turing in 1949, tests a machines ability to communicate like humans. 
A human interrogator communicates with a human and a machine over text-only channels. Both the human and machine try to act like a human. The interrogator has to tell which one is which. There are many more variants of this test, however, the basic tests falls short in a couple of ways. The test only measures a machine's ability to behave like a human and not if it is intelligent. Some human behaviour is unintelligent and some intelligent behaviour is inhuman. 
This test is also challenged by the [[Chinese Room Thought Experiment]], as the machine does not necessarily have to understand what it's outputting to convince the operator that it is human. 