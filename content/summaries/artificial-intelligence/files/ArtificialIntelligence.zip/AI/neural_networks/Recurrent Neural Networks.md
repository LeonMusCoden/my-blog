Conventional [[Feedforward Network|feedforward neural networks]] are designed to process and model individual or fixed length items only. However, in real world scenarios, the next data point often depends on the previous data point(s). This is called autocorrelation and appears everywhere: NLP, video, weather, ...

The idea of RNNs is to chain multiple copies of the same network. Each copy passes some piece of information to its successor. As a result, the information from previous steps is memorised and determines the current time step. This information is maintained in an internal "hidden" state vector $h_t$, which is updated during forward pass:
$$
h_t = f_\theta(h_{t-1}, x_t),
$$
where $f_\theta$ is the RNN function with parameters $\theta$ and $x_t$ is the input vector at step $t$. Graphically, this means the following:
![[RNN_function.png]]
An example structure would define the functions as follows:
$$
h_t = f_\theta (h_{t-1}, x_t) = tanh(W_{hh}h_{t-1} + W_{xh}x_t)
$$
$$
y_t = g_\phi(h_t) = softmax(W_{hy}h_t)
$$
That means we have 3 weight matrices to be learned. The $tanh$ function is a popular choice of activation function, but sometimes ReLU is used instead.

Depending on the task, the intermediate outputs can be fully ignored. For example, in a next word predictor, the inputs (one word per step) are calculated before the final output contains the prediction we're looking for:
![[word_predictor.png]]This is called a many-to-one sequence-to-sequence setup. There are other types of sequence-to-sequence setups:
![[sequence_to_sequence_setup.png]]
There are variations of that structure like deep (or stacked) RNNs:
![[deep_RNN.png]]
and bi-directional RNNs:
![[bi-directional_RNN.png]]
## Training
Training works similarly to standard backpropagation. The computation is unfolded through the sequence to propagate the activations and compute the gradients. This concept is referred to as *backpropagation through time* (BTT). 

The loss $\mathcal{L} = \sum_{t=1}^T \mathcal{L}_t$ aggregates over all time steps. 

The steps for backpropagation are as follows:
1. Compute gradients of loss with respect to output weights
	For $\pmb{W}_{hy}$. The gradients are $$\frac{\partial \mathcal{L}}{\partial \pmb{W}_{hy}} = \sum_{t=1}^T \frac{\partial \mathcal{L}_t}{\partial \pmb{y}_t} \cdot \frac{\partial \pmb{y}_t}{\partial \pmb{W}_{hy}}$$ Using the forward equation: $$ $$
2. Compute gradients with respect to hidden state
	The hidden state influences the output loss $\mathcal{L}_t$ and the future hidden states $h_{t+1}, \dots, h_T.$ The recursive formula is  $$
\frac{\partial \mathcal{L}}{\partial \mathbf{h}_t} = \frac{\partial \mathcal{L}_t}{\partial \mathbf{h}_t} + \sum_{k=t+1}^{T} \frac{\partial \mathcal{L}_k}{\partial \mathbf{h}_k} \cdot \frac{\partial \mathbf{h}_k}{\partial \mathbf{h}_t}.$$Key terms: 
$$
\frac{\partial \mathcal{L}_t}{\partial \mathbf{h}_t} = \frac{\partial \mathcal{L}_t}{\partial \mathbf{y}_t} \cdot \frac{\partial \mathbf{y}_t}{\partial \mathbf{h}_t}
$$
$$
\frac{\partial \mathbf{h}_k}{\partial \mathbf{h}_t} = \prod_{j=t+1}^{k} \frac{\partial \mathbf{h}_j}{\partial \mathbf{h}_{j-1}}
$$

3. Backpropagate through time
	Gradients with respect to $\mathbf{W}_{hh}$, $\mathbf{W}_{xh}$, and biases $\mathbf{b}_h$, $\mathbf{b}_y$ are computed as follows:
	1. Hidden-to-hidden weights:
	$$
   \frac{\partial \mathcal{L}}{\partial \mathbf{W}_{hh}} = \sum_{t=1}^{T} \frac{\partial \mathcal{L}}{\partial \mathbf{h}_t} \cdot \frac{\partial \mathbf{h}_t}{\partial \mathbf{W}_{hh}}
	$$
	$$
   \frac{\partial \mathbf{h}_t}{\partial \mathbf{W}_{hh}} = \sigma'(\mathbf{W}_{xh}\mathbf{x}_t + \mathbf{W}_{hh}\mathbf{h}_{t-1} + \mathbf{b}_h) \cdot \mathbf{h}_{t-1}
	$$
	1. Input-to-hidden weights:
	$$
   \frac{\partial \mathcal{L}}{\partial \mathbf{W}_{xh}} = \sum_{t=1}^{T} \frac{\partial \mathcal{L}}{\partial \mathbf{h}_t} \cdot \frac{\partial \mathbf{h}_t}{\partial \mathbf{W}_{xh}}
	$$
	$$
   \frac{\partial \mathbf{h}_t}{\partial \mathbf{W}_{xh}} = \sigma'(\mathbf{W}_{xh}\mathbf{x}_t + \mathbf{W}_{hh}\mathbf{h}_{t-1} + \mathbf{b}_h) \cdot \mathbf{x}_t
	$$

	3. Bias gradients:
	$$
   \frac{\partial \mathcal{L}}{\partial \mathbf{b}_h} = \sum_{t=1}^{T} \frac{\partial \mathcal{L}}{\partial \mathbf{h}_t} \cdot \frac{\partial \mathbf{h}_t}{\partial \mathbf{b}_h}
   $$
#### Challenges

While the concept of backpropagation through time allows RNNs to learn temporal dependencies, it introduces challenges related to the exploding and vanishing gradient problems. These issues arise from the repeated application of the chain rule to compute gradients across time steps.

**Vanishing gradient**
During backpropagation, gradients at earlier time steps are computed as the product of many small derivatives (from activation functions and weight matrices). If these derivatives are less than 1 (e.g., $\sigma'(z) \in (0, 1)$ for $tanh$ or sigmoid), the gradient diminishes exponentially as we move backward through time. This means gradients for earlier layers approach zero. Weight updates for these steps become negligible, leading to very slow learning. 

**Exploding gradient**
In some cases, gradients grow exponentially during backpropagation. This leads to extremely large weight updates and numerical instability (e.g., NaNs or overflows in computation). This happens because of repeated multiplication of large gradient values (eigenvalues of $\pmb{W}_{hh}$ greater than 1).

As a whole this makes learning long-term dependencies difficult for vanilla RNNs. 