---
lecture: "10"
---
Images are large datasets where each pixel contains 3x8bits (for RGB) of information. Traditional fully-connected [[Feedforward Network|feedforward neural networks]] connect every pixel to every neuron, resulting in far too many parameters for even small images. 

For example, ImageNet used 256px x 256px coloured images, i.e. 65536 pixels with 3 channels (R, G, B). It had 1000 classes and the following architecture: `{input layer} -> {100 neurons} -> {50 neurons} -> {output layer}`. That means it required $(256^2 * 3 * 100) + (100 * 50) + (50 * 1000) = 19,715,800$ parameters. 

Additionally, these fully connected architectures struggle to preserve spatial hierarchies in images, which are essential for recognising patterns like edges and textures.

Convolutions were introduced to address these problems. A convolution operation applies a filter (a small matrix of weights)  over the image to produce a feature map that highlights the presence of certain patterns, like edges or corners. This works because of three main principles:
1. **Local connectivity**: Assume nearby pixels are more relevant for forming patterns (like edges or textures). Instead of analysing every pixel globally, consider small patches of the image (*receptive fields*).
2. **Weight sharing**: Use the same set of weights (a *filter* or *kernel*) across the entire image. This drastically reduces the number of parameters and allows for pattern recognition that is invariant to position.
3. **Translation equivariance**: A pattern in one part of the image should be recognised wherever it appears in the image.

Let's take a look at a 1-dim convolution with an input signal $x[m]$ (green boxes) with length $L_x = 5$, a kernel (red boxes) with length $K = 3$, and an output signal $y[n]$ with length $L_y = 3$. We now slide the kernel over the input signal and calculate the dot product of the section of the input signal and the kernel:

```tikz
\begin{document}

\begin{tikzpicture}[node distance=1.2cm, every node/.style={minimum size=0.8cm, draw, fill=blue!20, font=\large}]

% Input Signal
\node[fill=green!20] (x0) at (0, 0) {1};
\node[fill=green!20] (x1) [right of=x0] {2};
\node[fill=green!20] (x2) [right of=x1] {3};
\node[fill=green!20] (x3) [right of=x2] {4};
\node[fill=green!20] (x4) [right of=x3] {5};

% Filter
\node[fill=red!20] (f0) at (0, -1.5) {-1};
\node[fill=red!20] (f1) [right of=f0] {2};
\node[fill=red!20] (f2) [right of=f1] {-1};

% Output Signal
\node[fill=yellow!20] (y0) at (1.2, -3) {$y[0]$};
\node[fill=yellow!20] (y1) [right of=y0] {$y[1]$};
\node[fill=yellow!20] (y2) [right of=y1] {$y[2]$};

% Arrows showing sliding filter
\draw[->, thick] (x0.south) -- (f0.north);
\draw[->, thick] (x1.south) -- (f1.north);
\draw[->, thick] (x2.south) -- (f2.north);

\draw[->, thick] (f0.south) -- (y0.north);
\draw[->, thick] (f1.south) -- (y0.north);
\draw[->, thick] (f2.south) -- (y0.north);

\end{tikzpicture}

\end{document}
```
$$
y[0] = 1 \cdot (-1) + 2 \cdot 2 + 3 \cdot (-1) = 0
$$

```tikz
\begin{document}

\begin{tikzpicture}[node distance=1.2cm, every node/.style={minimum size=0.8cm, draw, fill=blue!20, font=\large}]

% Input Signal
\node[fill=green!20] (x0) at (0, 0) {1};
\node[fill=green!20] (x1) [right of=x0] {2};
\node[fill=green!20] (x2) [right of=x1] {3};
\node[fill=green!20] (x3) [right of=x2] {4};
\node[fill=green!20] (x4) [right of=x3] {5};

% Filter
\node[fill=red!20] (f0) at (1.2, -1.5) {-1};
\node[fill=red!20] (f1) [right of=f0] {2};
\node[fill=red!20] (f2) [right of=f1] {-1};

% Output Signal
\node[fill=yellow!20] (y0) at (1.2, -3) {$y[0]$};
\node[fill=yellow!20] (y1) [right of=y0] {$y[1]$};
\node[fill=yellow!20] (y2) [right of=y1] {$y[2]$};

% Arrows showing sliding filter
\draw[->, thick] (x1.south) -- (f0.north);
\draw[->, thick] (x2.south) -- (f1.north);
\draw[->, thick] (x3.south) -- (f2.north);

\draw[->, thick] (f0.south) -- (y1.north);
\draw[->, thick] (f1.south) -- (y1.north);
\draw[->, thick] (f2.south) -- (y1.north);

\end{tikzpicture}

\end{document}
```
$$
y[1] = 2 \cdot (-1) + 3 \cdot 2 + 4 \cdot (-1) = 0
$$

```tikz
\begin{document}

\begin{tikzpicture}[node distance=1.2cm, every node/.style={minimum size=0.8cm, draw, fill=blue!20, font=\large}]

% Input Signal
\node[fill=green!20] (x0) at (0, 0) {1};
\node[fill=green!20] (x1) [right of=x0] {2};
\node[fill=green!20] (x2) [right of=x1] {3};
\node[fill=green!20] (x3) [right of=x2] {4};
\node[fill=green!20] (x4) [right of=x3] {5};

% Filter
\node[fill=red!20] (f0) at (2.4, -1.5) {-1};
\node[fill=red!20] (f1) [right of=f0] {2};
\node[fill=red!20] (f2) [right of=f1] {-1};

% Output Signal
\node[fill=yellow!20] (y0) at (1.2, -3) {$y[0]$};
\node[fill=yellow!20] (y1) [right of=y0] {$y[1]$};
\node[fill=yellow!20] (y2) [right of=y1] {$y[2]$};

% Arrows showing sliding filter
\draw[->, thick] (x2.south) -- (f0.north);
\draw[->, thick] (x3.south) -- (f1.north);
\draw[->, thick] (x4.south) -- (f2.north);

\draw[->, thick] (f0.south) -- (y2.north);
\draw[->, thick] (f1.south) -- (y2.north);
\draw[->, thick] (f2.south) -- (y2.north);

\end{tikzpicture}

\end{document}
```
$$
y[3] = 3 \cdot (-1) + 4 \cdot 2 + 5 \cdot (-1) = 0
$$
As is obvious, we loose some samples. Specifically, we loose $K-1$ samples, meaning $L_y = L_x - (K - 1) = 6 - (3 - 1) = 4$. We can avoid that by adding zeros at the limits of the input signal, so that the dimension of the output matches the one at the input. This is called *zero padding* and would make the input signal look as follows: 

```tikz
\begin{document}

\begin{tikzpicture}[node distance=1.2cm, every node/.style={minimum size=0.8cm, draw, fill=blue!20, font=\large}]

% Input Signal
\node[fill=green!20] (x0) at (0, 0) {0};
\node[fill=green!20] (x1) [right of=x0] {1};
\node[fill=green!20] (x2) [right of=x1] {2};
\node[fill=green!20] (x3) [right of=x2] {3};
\node[fill=green!20] (x4) [right of=x3] {4};
\node[fill=green!20] (x5) [right of=x4] {5};
\node[fill=green!20] (x6) [right of=x5] {0};

% Filter
\node[fill=red!20] (f0) at (2.4, -1.5) {-1};
\node[fill=red!20] (f1) [right of=f0] {2};
\node[fill=red!20] (f2) [right of=f1] {-1};

% Output Signal
\node[fill=yellow!20] (y0) at (1.2, -3) {$y[0]$};
\node[fill=yellow!20] (y1) [right of=y0] {$y[1]$};
\node[fill=yellow!20] (y2) [right of=y1] {$y[2]$};
\node[fill=yellow!20] (y3) [right of=y2] {$y[3]$};
\node[fill=yellow!20] (y4) [right of=y3] {$y[4]$};

% Arrows showing sliding filter
\draw[->, thick] (x2.south) -- (f0.north);
\draw[->, thick] (x3.south) -- (f1.north);
\draw[->, thick] (x4.south) -- (f2.north);

\draw[->, thick] (f0.south) -- (y2.north);
\draw[->, thick] (f1.south) -- (y2.north);
\draw[->, thick] (f2.south) -- (y2.north);

\end{tikzpicture}

\end{document}
```
Another parameter we can modify is *stride*, which is the step size of the convolutional filter. As a result, the length of the output sequence decreases by the stride factor, i.e. $L_y = L_x / S$ (assuming zero padding). 

These same ideas also work in 2D:
![[2d_convolutions.png]]
In image processing such filters are often to used manipulate images, in which case the filters are called Sobel filters. However, this assumes only a single channel (black and white), but we often want to handle coloured (RGB) images. A solution is to think of the input and kernel as volumes:
![[convolution_kernel_volume.png]]
Instead of a 5x5x3 kernel, we could also use three 5x5 kernels. This would produce a 28x28x3 output:
![[convolution_output_volume.png]]
But why stop there? We could add more kernels and therefore get more activation maps. This allows us to have even more features:
![[convolution_more_activation_maps.png]]
This is becoming complex very quickly, but we still have a big problem: How do we find the right kernel values to detect certain features? We can introduce activation functions to the output and apply the same learning processes as with traditional neural networks. The pipeline of a single layer then works like as follows:
1. Perform the convolution operation to produce the raw output (feature map)
$$
O(i, j) = \sum_{m=0}^{k-1} \sum_{n=0}^{k-1} I(i + m, j + n) \cdot K(m, n),
$$
	where $I$ is the input, $K$ the kernel, and $O$ the output.
2. Add a bias term $b$:
$$
O'(i,j) = O(i,j) + b
$$
3. Pass $O'(i,j)$ through an activation function $f(\cdot)$:
$$
a(i,j) = f(O'(i,j))
$$
	This gives the activated feature map.

The result is an equivalent to a neuron, whose weights (the kernel) can be learned as detailed [[Feedforward Network#Training|here]].

With this, we can now stack convolutions to create a [[Convoluted Neural Networks|convoluted neural network]]:
![[stacked_convolutions.png]]