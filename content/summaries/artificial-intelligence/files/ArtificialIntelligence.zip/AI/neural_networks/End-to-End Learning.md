---
lecture: "8"
---
is a learning paradigm where the system learns both features and classification functions together. Traditional machine learning often relied on handcrafted features and separated feature extraction from classification. End-to-end learning uses cascades of nonlinear transformations to learn adaptive representations.