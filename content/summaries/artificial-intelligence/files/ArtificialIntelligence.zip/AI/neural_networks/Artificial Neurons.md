## McCullock & Pitts Neuron

Inspired by biological neurons, the first mathematical model of an artificial neuron was created in 1943 by McCullock and Pitts. It works by having $d$ binary inputs $x_i \in \{0, 1\}$ from other neurons via axons. These inputs are combined by an *aggregation function* $z$. The output is passed to the *activation function* $f(z)$, which determines the binary output $a \in \{0,1\}$ of the neuron. 
![[artificial_neuron_mccullock_pitts.png]]
A simple aggregation and activation functions are $z= \sum_{i=1}^d x_i$ and $f(z) = \begin{cases}1 & \text{ if } z \geq \theta \\ 0 & \text{ if } z < \theta \end{cases}$. Depending on the chose $\theta$, we can achieve different logic gates:
![[artificial_neuron_logic_gates.png]]
However, a problem arises with XOR. This is because non-linearity is not supported by this model. Furthermore, it only allows for boolean input and output, all input are treated equally, and there is no learning process, since $\theta$ is hard-coded.
## Rosenblatt Perceptron
Clearly another solution was needed. Biological neurons have synapses, which control the weight (= importance) of a signal from another cell. Integrating that same feature into the artificial neuron would be closer to the biological neuron and would allow weights to be assigned to neurons. This is exactly what Frank Rosenblatt proposed in 1958. He modified the aggregation function to not only include inputs $x_i \in \mathbb{R}$, but also *weights* $w_i \in \mathbb{R}$: $z = \sum_{i=1}^d w_i x_i$. He also included a *bias* as input, which is always one. The weight for that input is denoted as $b \in \mathbb{R}$, resulting in the aggregation function $z = \sum_{i=1}^d w_i x_i + b$. He also simplified the activation function to $f(z) = \begin{cases}1 & \text{ if } z \geq 0 \\ 0 & \text{ if } z < 0 \end{cases}$. This neuron allows for non-binary inputs and a hyperplane for determining the output:
![[rosenblatt_perceptron_hyperplane.png]]
Rosenblatt also introduced a [[Supervised Learning|supervised learning]] algorithm:
1. Initiate weights $\pmb{w}$ randomly
2. Take one (random) sample $x_i$ and predict $\hat{y_i}$, which is essentially the neuron output $a$.
3. For wrong predictions update the weights $\pmb{w}$:
	a. If the output was $\hat{y_i} = 0$, but $y_i = 1$, increase the weights
	b. If the output was $\hat{y_i} = 1$, but $y_i = 0$, decrease the weights
4. Repeat until no errors are made
