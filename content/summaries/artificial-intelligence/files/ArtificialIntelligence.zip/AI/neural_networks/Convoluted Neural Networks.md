Convolutional Neural Networks (CNNs) are a specialized type of neural network designed for efficiently processing and analyzing data with a grid-like structure, such as images. They have revolutionized fields like computer vision.

The building blocks of CNNs are:
- **Convolutional Layers**:
    - Perform [[Convolutions|convolution]] operations, applying filters (kernels) to the input to extract features. This feature learning requires a lot of compute.
    - Each filter detects specific patterns like edges, textures, or shapes.
    - Output: Feature maps that highlight the presence of these patterns.
- **Activation Functions**:
    - Non-linear functions (e.g., ReLU) applied to the outputs of convolutional layers.
    - Add non-linearity, enabling the network to learn complex patterns.
- **Pooling Layers**:
    - Down-sample feature maps to reduce spatial dimensions while retaining important information.
    - Common [[Pooling|pooling techniques]]: Max pooling and Average pooling.
    - Benefits: Reduces computational complexity, enhances translation invariance, and prevents overfitting.
- **Fully Connected Layers**:
    - Flatten feature maps into a vector and pass it through fully connected layers for classification or regression. This classification requires a lot of memory.
    - Serve as the decision-making part of the network.
    - Probability distribution of the output using Softmax

## Architectures
A well-known example is LeNet, which was the first ConvNet (convoluted network), which used the tanh activation function and had 2 [[Convolutions|convolution]] and 3 fully connected layers:
![[LeNet.png]]
A famous test for large scale image classification is the ImageNet Large Scale Visual Recognition Challenge (ILSVRC). The top-performing models of each year show the way forward in terms of architecture:
![[ILSVRC.png]]As we can see, starting with *AlexNet*, deep neural networks allowed for a lot of improvement, but with the introduction of *VGGNet* with 19 layers, the race for very deep neural networks started. 

VGGNet used smaller filters with only 3x3 conv, stride 1, and padding 1. In between some conv layers, it added 2x2 max pools with stride 2. Why do that? More smaller filters allows building deeper networks with less parameters. In the case of VGGNet, a stack of three 3x3 conv (stride 1) layers has the same effective receptive field as one 7x7 conv layer, but only uses 2592 parameters compared to 4704. 

Following VGGNet, the desire for deeper networks led to the development of architectures like *GoogLeNet* and *ResNet*. 
### GoogLeNet (2014)
introduced the inception module. It aimed at increasing network efficiency and improving feature extraction.
![[GoogLeNet.png]]
- **Inception Module**:
    - Combines multiple convolution operations of varying sizes (1x1, 3x3, 5x5) and max pooling in parallel.
    - Outputs are concatenated, allowing the network to capture multi-scale features.
- **1×1 Convolutions**:
    - Used for dimensionality reduction to reduce the computational cost of larger filters.
    - Also acts as a bottleneck layer to increase computational efficiency.
- **Auxiliary Classifiers**:
    - Additional classifiers added at intermediate layers to mitigate vanishing gradients and regularise training.
- **Structure**:
    - GoogLeNet has 22 layers, far deeper than VGGNet, yet with fewer parameters (~6.8 million vs. ~138 million for VGGNet).

**Advantages**:
- Efficient feature extraction and multi-scale representation.
- Reduced number of parameters compared to VGGNet.

**Disadvantages**:
- Complex architecture and reliance on manual design for the Inception module.

#### ResNet (2015)
introduced residual connections, enabling the training of ultra-deep networks (for example, 152 layers).
![[ResNet.png]]
- **Residual Connections**:
    - Shortcut connections bypass one or more layers, allowing the network to learn residual mappings:$$y = F(x, \{W_i\}) + x$$Instead of learning the full transformation $H(x)$, the network learns $F(x) = H(x) - x$, simplifying the optimisation process.
- **Impact**:
    - Resolved the vanishing gradient problem, which previously hindered training of very deep networks
    - Showed that increasing depth improves performance up to a certain point.
- **Performance**:
    - ResNet's residual connections facilitated the development of extremely deep architectures like ResNet-50, ResNet-101, and ResNet-152.

**Advantages**:
- Improved gradient flow, enabling very deep architectures.
- Simpler design compared to GoogLeNet, making it easier to scale.

**Disadvantages**:
- Computationally expensive for very deep versions.
- Marginal performance improvement with extreme depth.
### Dropout
Dropout is a form of regularisation to prevent overfitting. It sets each hidden unit activation to 0 with 50% probability. 
![[dropout.png]]
## Data Augmentation
As important as the architecture is, the amount and quality of the data is also relevant. The issue is that gathering large amounts of high quality data is hard, therefore, we have to find ways to make more use of the data we have. This is called data augmentation. Depending on the exact data type, there are many ways to augment data.

For images, a common way is to crop images, for example from 256x256px to 224x224. Taking centre and corner crops results in different images. Additionally, we can perform horizontal flips or even sometimes rotations. This procedure adds more variation to the training data and therefore increases the amount of training data.

