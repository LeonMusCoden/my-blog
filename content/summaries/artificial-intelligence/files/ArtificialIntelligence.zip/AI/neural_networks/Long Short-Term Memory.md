---
lecture: "11"
---
The LSTM network is a type of [[Recurrent Neural Networks|RNN]] designed to address the vanishing and exploding gradient problems in standard RNNs. It introduces a memore cell structure that allows the network store, update and retrieve long-term dependencies more effectively. 

LSTMs utilise *gates* to control the flow of information in and out of a cell state. These gates are learnable and ensure that important information persists, while irrelevant or outdated information is discarded.
## Structure
![[LSTM.png]]
An LSTM cell has 3 inputs, the previous cell state $c_{t-1}$, the previous hidden vector $h_{t-1}$, and the input vector $x_t$, as well as 2 outputs, the new cell state $c_t$ and the new hidden vector $h_t$. The top path for $c_{t-1}$ and $c_t$ represents the cell's long-therm memory or information highway. It enables mostly unchanged information flow. The bottom paths are responsible for short-therm information. 

The control of information is controlled by 4 components:
1. Forget gate $f_t$: Controls which parts of the previous cell state $c_{t-1}$ should be discarded or retained
2. Candidate memory $c'_t$: Represents the new information generated from the current input and the previous hidden state.
3. Input gate $i_t$: Determines how much of the new information (candidate memory) should be added to the cell state.
4. Output gate $o_t$: Determines how much of the updated cell state $c_t$ should influence the hidden state $h_t$.
Whenever a component determines the amount of information to pass on, the sigmoid $\sigma$ function is used because its $y$ values are in $[0, 1]$. When a component is used to determine the information, the $tanh$ function is used because its values are in $[-1, 1]$ (remove / add the information). 

The calculations work as follows:
- $f_t = \sigma_g (W_f x_t + U_f h_{t-1} + b_f)$
- $i_t = \sigma_g (W_i x_t + U_i h_{t-1} + b_i)$
- $o_t = \sigma_g (W_o x_t + U_o h_{t-1} + b_o)$
- $c'_t = tanh_c (W_c x_t + U_c h_{t-1} + b_c)$
All weights (variables $W$ and $U$) and biases (variables $b$) are trained.
What makes the cell state stable is the fact that it is never multiplied with weights. That eliminates the gradient vanishing and explosion problems. 