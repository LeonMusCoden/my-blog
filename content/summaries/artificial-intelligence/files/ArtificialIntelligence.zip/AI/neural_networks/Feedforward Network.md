---
lecture: "8"
---
A feedforward [[Neural Networks|neural network]] is free of cycles, meaning every neuron is connected only with neurons from the previous and the next layer. There are exceptions such as *skip connections* or *residual connections*. 

Two layers are called *fully connected*, if there exists a pairwise connection between all neurons. 
# Notation
The basic notation for a neural network with $L$ layers and $n_l$ neurons for each layer $l$ works as follows:
- $a_i^l$ is the *activation* or output of neuron $i$ in layer $l$.
- $b_i^l$ is the *bias* of neuron $i$ in layer $l$
- $w_{ik}^l$ is the *weight* of the connection between neuron $i$ in layer $l - 1$ and neuron $k$ in layer $l$
![[neural_network_notation.png]]
This is a bit confusing, so let's simplify it by using the vectorised notation instead:
- Each layer's activation is represented as $\pmb{a}^l = (a_1^l, \dots, a_{n_l}^l)^T$.
- Each layer's bias is represented as $b^l = (b_1^l, \dots, b_{n_l}^l)^T$.
- The weights between layer $l-1$ and $l$ form a matrix $$\pmb{W}^l = \begin{bmatrix} w_{1,1}^{l} & \dots & w_{1,n_{l-1}}^{l} \\ \vdots & \ddots & \vdots \\ w_{n_l,1}^{l} & \dots & w_{n_l,n_{l-1}}^{l} \end{bmatrix} \in \mathbb{R}^{n_l \times n_{l-1}}.$$The top-left weight, $w_{1,1}^l$ is the weight between the first neuron of layer $l-1$ and the first neuron of layer $l$. The bottom-right weight, $w_{n_l, n_{l-1}}^l$, is the weight between the last neuron of layer $l-1$ and the last neuron of layer $l$.
- The input to the network is $\pmb{x} = (x_1, \dots, x_d)^T = (a_1^1, \dots, a_{n_1}^1)^T$.
- The output of the network is $\hat{y} = (\hat{y_1}, \dots, y_c)^T = (a_1^L, \dots, a_{n_L}^L)^T$.
# Forward Pass
The flow of information from the input to the output of the entire network is called a *forward pass*. Let's use the vector notation to do that. 
Given an input vector $\pmb{a}^1$, the signal is propagated layer by layer through the network. In each layer the aggregated input of each neuron $z_i^l$ is collected in vectorised form: $\pmb{z}^l = \pmb{W}^l \cdot \pmb{a}^{l-1} + \pmb{b}^l$. Now to determine the output of layer $l$, the [[Activation Function|activation function]] $f(\pmb{z}^l)$ is applied element-wise to $\pmb{z}^l$: $\pmb{a}^l = f(\pmb{z}^l) = (f(z_1^l), \dots, f(z_{n_l}^l))$. 

Logically, the entire signal transformation in a forward pass follows a path from the inside to the outside:
$$
\hat{\pmb{y}} = \pmb{a}^L = f(\pmb{W^L} f(\pmb{W}^{L-1} \dots f(\pmb{W}^3 f(\pmb{W}^2 \pmb{a}^1 + \pmb{b}^2) + \pmb{b}^3) + \pmb{b}^{L-1}) + \pmb{b}^L). 
$$
# Classification
A simple classification neural network uses one-hot encoding of class labels into a vector, where $\hat{y_i} = 1$ means presence of class $i$ and $\hat{y} = 0$ means no presence. Mathematically that means $\pmb{y} = (y_1, \dots, y_c)^T$ with $\sum_i^c y_i = 1$. The output is often just the logits (the raw data), meaning $\hat{y_j} = a_j^L$. 
However, even with classification, it is often insightful to have probabilistic outputs. For that, *softmax* is commonly applied:
$$
\hat{y_j} = a_j^L = \frac{e^{z_j^L}}{\sum_k e^{z_k^L}}.
$$
The result still sums up to 1, i.e. $\sum_j a_j^L = 1$. 
An improvement of softmax is *logSoftmax*, which is numerically stable (avoid NaN in extreme cases) and more computationally efficient:
$$
\hat{y_j} = a_j^L = \log{\frac{e^{z_j^L}}{\sum_k e^{z_k^L}}} = \log{e^{z_j^L}} - \log{\sum_k e^{z_k^L}}.
$$
This can be approximated to
$$
\hat{y_j} = a_j^L = \log{e^{z_j^L}} - \log{\sum_k e^{z_k^L}} \approx z_j^L - \max(z^L).
$$
## Training
Let's assume we have a binary classification model with only an input layer $\pmb{x}$ and an output layer with a single neuron $a$ that uses a sigmoid [[Activation Function|activation function]]. For the [[Machine Learning#Learning Setup|learning setup]] to be complete, we need an objective and optimiser.
### Objective function
The goal is to make $\hat{y_i} = \sigma(\pmb{w}^T x_i + b) \approx y_i \;\; \forall(x_i, y_i) \in \mathcal{D}_{\text{train}}$.

The predicted output $\hat{y}$ is the probability of the positive class $y = 1$:
$$
P(y = 1 | x) = \hat{y}, \quad P(y = 0 | x) = 1 - \hat{y}. 
$$
For a single data point $(x, y)$, the likelihood of observing the true label is
$$
P(y | x) = \hat{y}^y \cdot (1 - \hat{y})^{1-y}.
$$
Now, we take the logarithm of the likelihood, called the log-likelihood:
$$
\log P(y|x) = y \log(\hat{y}) + (1-y) \log(1\hat{y}).
$$
We do that because it simplifies products into sums and stabilises numerical computations for probabilities close to 0 or 1.

If $y = 1$, this becomes $\log(\hat{y})$, rewarding the model for predicting a high $\hat{y}$. If $y = 0$, this becomes $\log(1 - \hat{y})$, rewarding the model for predicting a low $\hat{y}$. For example, if $y = 1$ and $\hat{y} = 0.9$, then $\log(0.9) \approx 0.05$, compared to $\hat{y} = 0.1$, then $\log(0.1) = -1$. 

To construct a loss function, we want a function the value to be high if the error is high, therefore, we take the negative log-likelihood (NLL), which results in our *loss function*:
$$
\mathcal{L}(\hat{y}, y) = -(y \log \hat{y} + (1 - y) \log(1 - \hat{y})).
$$
Running $\mathcal{L}$ over $N$ data points using the parameters $\pmb{w}$ and $b$, yields the *objective (or cost) function*:
$$
\mathcal{J}(\pmb{w}, b) = \frac{1}{N} \sum_{i=1}^N \mathcal{L}(\hat{y}_i, y_i).
$$
We can expand to $M$ outputs $\hat{\pmb{y}} = \pmb{a} = (a_1, \dots, a_M)^T$ and aggregation $z_i = \pmb{w}_i^T \pmb{x} + b_i$. Then, the loss function becomes
$$
\mathcal{L}(\hat{y}, y) = - \sum_{m=1}^M y_m \log \hat{y}_m
$$
and the objective function becomes
$$
\mathcal{J}(\pmb{w}, b) = - \sum_{i = 1}^N \sum_{m=1}^M y_{i, m} \log \hat{y}_{i, m}.
$$
### Optimiser
The goal of the optimiser is to find a point ($\pmb{w}, b$) that is at the minimum of the surface constructed by the objection function:
$$
\pmb{w}^*, b^* = \text{arg}\min_{\pmb{w},b} \mathcal{J}(\pmb{w}, b).
$$
This surface is convex and there is a theoretical guarantee to find a global optimum.
![[ojective_function_surface.png]]
The solution to this optimisation problem is gradient descent. The idea is to follow the gradient (= the slope) of $\mathcal{J}$. We can do this because the activation function $\sigma(z)$ is differentiable. 
The process works like as follows:
1. Initialise $\pmb{w}, b$ randomly. The starting point should have good variance in the weights, yield a good gradient, and avoid extreme weight values. A good option is *Xavier normal initialisation*.
2. Generate prediction in forward pass
3. Calculate loss
4. Update weight in [[#Backward Pass|backward pass]] according to$$
	\pmb{w}^{(i+1)} = \pmb{w}^{(i)} - \eta \frac{\partial \mathcal{J}}{\partial \pmb{w}^{(i)}} \qquad b^{(i+1)} = b^{(i)} - \eta \frac{\partial \mathcal{J}}{\partial b^{(i)}},
	$$where $\eta$ represents the learning rate. (See [[#Gradient Calculation Using the Chain Rule]] for the calculation)
Every iteration of this process is called an *epoch*. The process is repeated until convergence:
![[gradient_descent.png]]
However, there are many problems:
- Usually there are *local optima*, which can lead to the false assumption of a "perfect" model.
- *Saddle points and plateaus* have no gradient, therefore, the learning stops.
- The surfaces can't be viewed in practice because of high-dimensionality. 

Factors that influence convergence include:
- **Loss function**: Determines the optimisation objective. Some functions are harder to minimise due to complexity or local minima.
- **Optimizer**: Choice of optimization algorithm (e.g., SGD, Adam) affects the rate and stability of convergence.
- **Learning rate**: Controls the size of parameter updates. Too high causes instability, and too low slows convergence.

In practice, the following tricks help:
- **Learning Rate Schedule**:
    - Dynamically adjust the learning rate during training (e.g., reduce it after a plateau).
- **Early Stopping**:
    - Halt training if the loss or validation metrics don’t improve for a fixed number of iterations.
    - Prevents overfitting and saves computation time.
- **Validation Data Verification**:
    - Monitor performance on a separate validation dataset to ensure generalization.

Another trick is to use *stochastic gradient descent* (SGD), which updates parameters using the gradient of a single sample. This is faster but introduces noise, leading to less stable updates. A more balanced approach is *mini-batch* SGD, which balances between full gradient descent and SGD by using a small batch of samples. This aims to combine speed and stability.
### Backward Pass
The process of computing gradients and propagating error signals backward through the network is known as the *backward pass*. This is essential for updating the weights and biases during training. The gradients are computed using the **chain rule**, which calculates how changes in one layer affect the loss function by propagating derivatives layer by layer.
#### Gradient Calculation Using the Chain Rule
For a network with $L$ layers, the goal is to compute the gradient of the loss $\mathcal{L}$ with respect to each weight matrix $\pmb{W}^l$. This involves calculating:
$$
\frac{\partial \mathcal{L}}{\partial \pmb{W}^l}
$$
using the chain rule.

If $\pmb{z}^l = \pmb{W}^l \pmb{a}^{l-1} + \pmb{b}^l$ and $\pmb{a}^l = f(\pmb{z}^l)$, the chain rule can be applied as:
$$
\frac{\partial \mathcal{L}}{\partial \pmb{W}^l} = \frac{\partial \mathcal{L}}{\partial \pmb{a}^l} \cdot \frac{\partial \pmb{a}^l}{\partial \pmb{z}^l} \cdot \frac{\partial \pmb{z}^l}{\partial \pmb{W}^l}.
$$
#### General Steps
1. Compute the gradient of the loss with respect to the output layer ($\pmb{a}^L$) and backpropagate through intermediate layers:
    $$
    \frac{\partial \mathcal{L}}{\partial \pmb{a}^l} = \frac{\partial \mathcal{L}}{\partial \pmb{a}^{l+1}} \cdot \frac{\partial \pmb{a}^{l+1}}{\partial \pmb{z}^{l+1}} \cdot \frac{\partial \pmb{z}^{l+1}}{\partial \pmb{a}^l}.
    $$
2. Calculate the gradients for weights $\pmb{W}^l$:
    $$
    \frac{\partial \mathcal{L}}{\partial \pmb{W}^l} = \frac{\partial \pmb{z}^l}{\partial \pmb{W}^l} \cdot \frac{\partial \pmb{a}^l}{\partial \pmb{z}^l}.
    $$
### Vanishing gradient problem
If we take this current neural network and add more layers to it, we would notice the back propagation works less and less effectively the further we go from the back to the front of the network. This is because the [[Activation Function|activation functions]] have gradients in the range $[-1;1]$, and backpropagation computes gradients using the chain rule (as seen in [[#Forward Pass]]). This has the effect of multiplying $n$ of these small numbers to compute gradients of the early layers in an $n$-layer network, meaning that the gradient (error signal) decreases exponentially with $n$ while the early layers train very slowly. 

One solution is to add skip connections.

### Challenges for training 

- **Neural network training is NP-complete**: NP-complete problems are those for which no efficient algorithm exists to find the optimal solution in polynomial time. However, verifying a given solution is possible in polynomial time.
- Loss surface and optimisation problem of neural networks are **non-convex**: A loss function is non-convex if it has multiple local minima, saddle points, or plateaus, rather than a single global minimum.
- Neural network training optimisation is **high-dimensional**
- Neural network training is sensitive to **hyperparameters** (such as learning rate, batch size, number of layers and neurons, ...) and **random initialisation**