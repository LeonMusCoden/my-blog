---
lecture: "8"
---
is a [[Machine Learning|machine learning]] approach considered to be a universal function approximator. It is an [[End-to-End Learning|end-to-end learning]] approach where features are learned together with the classification. 

There are many different types of architectures for neural networks, including multilayer perceptrons (MLP), [[Recurrent Neural Networks|recurrent neural networks (RNN)]], [[Long Short-Term Memory|long-short term memory (LSTM)]], deep autoencoders, [[Convoluted Neural Networks|convolutional neural networks (CNN)]], generative adversarial networks (GAN), and more.

The base of neural networks are [[Artificial Neurons|artificial neurons]], connected to form a weighted directed graph. The network is typically organised into layers. The first layer accepts the input features, called the input layer. Then come a variable number of hidden layers that perform nonlinear transformations. Finally, an output layer produces the predictions.
![[neural_network.png]]
This means every neuron only receives inputs from the previous layer and outputs to the next layer. This is called a [[Feedforward Network|feedforward network]].

