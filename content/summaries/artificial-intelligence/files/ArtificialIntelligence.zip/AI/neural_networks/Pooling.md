---
lecture: "10"
---
is a down-sampling operation used in [[Convoluted Neural Networks|CNNs]] to reduce the spatial dimensions (width and height) of feature maps while retaining important information. 

This obviously reduces computational complexity and memory usage, ultimately speeding up training and inference.

There are many different *pooling schemes*:
![[pooling_schemes.png]]
However, there is some discussion about the need for pooling. For example, some argue that max-pooling can simply be replaced by a convolutional layer with increased stride without loss in accuracy (tested on several image recognition benchmarks). 