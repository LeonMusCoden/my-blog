---
lecture: "2"
---
On a high level, an agent is any entity that can perceive its environment and act upon it.

![[agent.png]]
**Components**
- Percepts: Inputs and agent receives from its environment (visual data, text input, sensor readings)
- Actions: Outputs or actions by an agent (moving a robot, answering a query)
- Performance Measure: A criterion that evaluates how successful the agent is in achieving its goal
- [[Properties of Environments|Environment]]: The context in which the agent operates. It can be defined using the [[PEAS Description]].

An agents actions are controlled by an agent function, which maps percept histories to actions: 
$$
f: P^* \rightarrow A
$$
The function defines the [[Types of Agents|type of agent]].

Before an agent can start searching for solutions, a goal must be identified, and a well defined [[Problem Definition|problem definition]] must be formulated.