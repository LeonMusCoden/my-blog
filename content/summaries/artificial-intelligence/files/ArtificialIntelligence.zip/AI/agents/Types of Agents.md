---
lecture: "2"
---
The [[Agents|agent]] function can have several degrees of complexity:
- **Table**: Predefined mappings of percepts to actions, no logic or reasoning.
- **Rules**: Simple conditional logic ("if-then" statements) guiding actions.
- **Search**: Deliberative reasoning by exploring possible actions and outcomes.
- **Learning**: Adaptive behaviour by improving from experience or data.
From these we can build different types of agents, including
- [[Simple-Reflex Agent]]
- [[Model-based Reflex Agent]]
- [[Goal-based Agent]]
- [[Utility-based Agent]]
- [[Learning-based Agent]]
