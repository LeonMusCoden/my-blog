---
lecture: "2"
---
Goal-based agents are a [[Types of Agents|type of agent]]. They work as follows:
- Chooses actions to achieve specific goals
- Generates possible sequences of actions and predicts resulting states
- Considers future states with their alignment with the goal
For example, a navigation system aiming to reach a destination.
![[goal-based_agent.png]]