---
lecture: "2"
---
Environments that [[Agents|agents]] can be in are classified by the following properties:

**Fully-observable vs. partially-observable**
If an agent's sensors give it access to the complete state of the environment at each point in time, then the task is fully-observable. For example, an automated taxi can not see what other drivers are thinking, therefore, it is partially observable.

**Deterministic vs. stochastic**
If the next state of the environment is completely determined by the current state and the action executed by the agent, then the environment is deterministic. For example, the automated taxi is stochastic because of other road users. 
A special case is if the environment is deterministic except for the actions of other agents, in which case the environment is strategic.

**Episodic vs. Sequential**
The agent's experience is divided into atomic episodes. Each episode consists of the agent perceiving and then performing a single action and the choice of action in each episode depends only on the episode itself. 
For example, an episodic environment is image classification, while chess is a sequential environment.

**Static vs. dynamic**
If the environment can change while an agent is deliberating, then the environment is dynamic. If the environment does not change, but the agent's performance score does, then the environment is semi-dynamic (for example a timed chess game).

**Discrete vs. continuous**
A discrete environment has a limited number of distinct, clearly defined percepts and actions. For example, a game of chess is discrete, while moving a robot is continuous. 

**Single agent vs. multi-agent**
A multi-agent environment has other involved agents. These might act competitively or cooperatively. 

The real world is partially observable, stochastic, sequential, dynamic, continuous, multi-agent. 