---
lecture: "2"
---
- Acts solely based on current percepts
- Acts according to predefined rules that match the current state
This [[Types of Agents|type of agent]] is very simple, but very limited in terms of intelligence. Additionally, it only works if the environment is fully observable. 
For example, a thermostat that adjusts the heating based on current temperature.

![[simple-reflex_agent.png]]