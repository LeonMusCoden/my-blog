---
lecture: "2"
---
Learning-based agents are a [[Types of Agents|type of agent]]. They work as follows:
- Improves its performance over time by learning from data or experience
- Uses mechanisms like reinforcements learning or supervised learning
It can be divided into 4 conceptual components:
1. **Learning elements** are responsible for improvements
2. **Performance elements** are responsible for selecting external actions
3. **Critic** tells the learning element how well the agent is doing with respect to a fixed performance standard
4. **Problem generator** is responsible for suggesting actions that will lead to new and informative experience
For example, a self-driving car improving its driving strategy.
![[learning-based_agent.png]]