---
lecture: "2"
---
To design an agent, we must specify its environment. We can do that using the PEAS description:
- P: Performance Measure
- E: [[Properties of Environments|Environment]]
- A: Actuators
- S: Sensors
For example, an automated taxi can have the following PEAS description:
- P: Safety, destination, profits, legality, comfort
- E: US streets, traffic, pedestrians, weather
- A: Steering, accelerator, brake, horn
- S: Video, accelerometers, gauges, engine sensors, GPS