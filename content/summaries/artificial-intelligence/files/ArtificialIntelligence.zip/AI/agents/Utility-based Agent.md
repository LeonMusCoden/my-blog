---
lecture: "2"
---
Utility-based agents are a [[Types of Agents|type of agent]]. They work as follows:
- Maximizes a utility function, measuring desirability or value of outcomes
- Balances multiple goals or preferences and quantifies trade-offs
For example, a recommender system suggesting the "best" option.
![[utlity-based_agent.png]]