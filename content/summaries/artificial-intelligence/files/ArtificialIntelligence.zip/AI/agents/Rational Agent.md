---
lecture: "2"
---
A **rational agent** is an [[Agents|agent]] that strives to do the right thing, based on what it can perceive and the actions it can perform. The right actions is the one that will maximise its performance measure. 

It is important to note that a rational agent can still make mistakes because it doesn't have all relevant information. That means that a rational agent is neither omniscient, clairvoyant, nor necessarily successful. 

An agent is **autonomous** if its behaviour is determined by its own experience and has the ability to learn and adapt. 