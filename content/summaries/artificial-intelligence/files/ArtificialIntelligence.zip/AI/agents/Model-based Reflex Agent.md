---
lecture: "2"
---
Model-based reflex agents are a [[Types of Agents|type of agent]]. They work as follows:
- Maintains an internal state (model) of the environment
- Uses percept history to handle partially observable environment
- It then chooses an action in the same way as the reflex agent
For example, a roomba that keeps track of cleaned and uncleaned areas to avoid repetition.

![[model-based_reflex_agent.png]]
