---
lecture: "3"
---
An informed [[Search Algorithms|search algorithm]] uses an evaluation function $f(n)$ for each node to estimate utility without expanding the whole graph. Most algorithms expand nodes based on the lowest calculated cost. 

Different heuristics can act as evaluation function, for example, $f(n) = h_{SLD}(n) =$ straight-line distance from $n$ to goal state. 

The most notable informed search algorithms are [[Greedy Search|greedy search]] and [[A* Search|A* search]].