---
lecture: "3"
---
Search algorithms are judged on the basis of 
- **Completeness**: Whether the algorithm is guaranteed to find a solution if one exists
- **Optimality**: Whether the algorithm finds the best solution when multiple solutions exist
- **Time complexity**: The number of nodes the algorithm has to explore before finding a solution
- **Space complexity**: The amount of memory the algorithm requires during its execution

Space and time complexity are usually expressed in terms of
- *b*: Branching factor (= average number of child nodes per node)
- *d*: Depth of the shallowest solution
- *m*: Maximum depth of the search space
For example, BFS has a time and space complexity of $O(b^d)$ because it explores and stores all nodes at each level up to depth $d$.

