---
lecture: "3"
---

- Explores as far as possible along each branch before backtracking
- Uses a stack (explicit or implicit via recursion) to keep track of the path
- Time complexity: $O(b^m)$