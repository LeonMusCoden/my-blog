---
lecture: "3"
---
An [[Informed Search|informed search]] algorithm that combines the cost to reach a node $g(n)$ and a heuristic $h(n)$ to estimate the cost to reach the goal from that node. The estimated total cost of the a path through $n$ to the goal is $f(n) = g(n) + h(n)$. 
That means compared to [[Greedy Search|greedy search]], A* aims to avoid expanding paths that are already expensive. 

The heuristic $h(n)$ must have the following properties:
- **Admissible**: $h(n) \leq h^*(n)$, where $h^*(n)$ is the true cost from $n$. That means the heuristic **never overestimate the true cost** of reaching the goal. 
- **Consistent / monotonic**: Fulfils the general triangle inequality, meaning the cost from $n$ to the goal through any successor $n'$ is no less than the direct estimated cost from $n$ to the goal. Mathematically, that is expressed as $h(n) \leq c(n,n') + h(n')$, where $c(n,n')$ is the cost of the edge from $n$ to $n'$. 

A* is complete and optimal. The time complexity depends on heuristic accuracy, but in the worst case $O(b^d)$, where $d$ is the depth of the optimal solution.