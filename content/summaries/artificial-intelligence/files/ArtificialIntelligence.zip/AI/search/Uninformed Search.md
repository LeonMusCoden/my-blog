---
lecture: "3"
---
An uninformed (also known as blind or brute-force) [[Search Algorithms|search algorithm]] generates the search tree without using any domain specific knowledge. 

All they can do is generate successors and distinguish a goal state from a non-goal state. Therefore, exponential-complexity search problems can not reasonably be solved by uninformed algorithms for any but the smallest instances.

These algorithms only differ by the order in which they expand their nodes locally. The two key algorithms are [[Breadth-First Search|breath-first search]] and [[Depth-First Search|depth-first search]].
