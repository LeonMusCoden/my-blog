---
lecture: "3"
---
An [[Informed Search|informed search]] algorithm that expands the node that appears to be closest to the goal based on a heuristic function $h(n)$.

It is not optimal because it may get stuck in local minima or take suboptimal paths. It is also not complete as it might fail in infinite or cyclic state spaces. However, it can be complete in finite space with repeated state checking.

It has a time complexity of $O(b^m)$ and space complexity of $O(b^m)$, where $b$ is the branching factor and $m$ is the maximum depth.

For example, lets consider the following city travel from Arad to Bucharest:
![[greedy_search_city_travel.png]]
As we can see, greedy search chose the red path even though the green one would be shorter. This is because it is only forward looking and does not consider the cost of reaching node $n$. An algorithm that does include this statistic is [[A* Search|A*]].