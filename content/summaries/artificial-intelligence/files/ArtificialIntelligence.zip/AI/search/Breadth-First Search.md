---
lecture: "3"
---

- Explores nodes level by level, starting from the root
- Ensures all nodes at the current depth are visited before moving to the next depth
- Time complexity: $O(b^d)$
