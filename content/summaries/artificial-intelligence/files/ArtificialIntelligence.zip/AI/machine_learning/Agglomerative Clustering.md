---
lecture: "7"
---
is a [[Unsupervised Learning#Hierarchical clustering|hierarchical clustering]] algorithm. It start by having each sample $x_i$ be a singleton cluster. Then, it iteratively picks the two clusters $X, Y$ with minimum distance $dist(X,Y)$ and merges them to a new cluster $Z = X \cup Y$. 

There are different linkage strategies:
- Single linkage: $dist(X,Y) = \min_{x\in X, y\in Y} ||x - y||$, i.e. the minimal distance between 2 samples in the clusters $X$ and $Y$.
- Complete linkage: $dist(X,Y) = \max_{x \in X, y \in Y} ||x - y||$, i.e. the maximal distance between 2 samples in the clusters $X$ and $Y$.
- Average linkage: $dist(X,Y) = \frac{1}{|X| \cdot |Y|} \sum_{x \in X, y \in Y} ||x - y||$, i.e, the average distance between all samples in each cluster.
