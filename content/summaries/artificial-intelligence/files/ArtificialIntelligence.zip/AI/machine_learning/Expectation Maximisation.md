is a general algorithm for finding maximum likelihood estimates of parameters in statistical models, particularly when the data involves latent variables or incomplete observations.

Latent variables are unobserved variables $U$ that influence the observed data $D$, such as cluster assignments. EM seeks to maximise the likelihood of observed data: $\theta^* = \text{argmax}_\theta P(D|\theta)$, where $\theta$ represents the parameters of the model.  

To that, we initialise the start parameter $\theta^0$ randomly. Then, we alternate two steps:
- E-step: calculate $P(U | D, \theta^t)$ to estimate the hidden structure of the data.
- M-step: find new $\theta^{t+1}$, such that $$\theta^{t+1} = \text{argmax}_\theta \; \mathbb{E}_{P(U|D,\theta^t)} [\log P(D, U | \theta)]$$to refine the model parameters based on the estimated structure.

Compared to [[k-Means]], EM can be used for finding isotropic (Gaussian) or non-isotropic cluster centres. It uses probabilistic matching of samples to cluster memberships.