---
lecture: "7"
---
The goal of unsupervised learning is to discover hidden patterns, dependencies, or distributions in the data without labelled outputs. Tasks include clustering, dimensionality reduction, and reconstruction. 

A dataset $X$ is defined as having samples $x_1, \dots, x_n \in \mathbb{R}^d$ (feature space) with no labels. Each sample is denoted by $(x_i) \rightarrow (x_1), \dots, (x_d)$. 
## Clustering
Clustering is process of automatic partition of a dataset into coherent parts, called clusters. It's particularly useful if we have a lot of data but do not know what we're looking for.
Let's imagine a fish factory with two types of fish, salmon and sea bass. We have a system that measures the length and width of each fish. A supervised system would have labelled data points from which a system could learn. In unsupervised learning, we can use clustering to distinguish the two types without ever having to label train data. 

However, there is a chicken-egg problem with finding centres and assigning cluster membership.

There are 2 key types of clustering that distinguish themselves in the way they handle said problem:
### Centeroid clustering
starts with the entire dataset and divides the dataset top-down, focusing on mean-shifts. It's an interleaved approach between cluster membership assignment and mean recalculation. Typical approaches include [[k-Means]] and expectation maximisation. 
### Hierarchical clustering
starts with a single sample per cluster (called singleton) and merges them bottom-up. It focuses on linkage methods and provides a hierarchical structure. Typical algorithms include [[Agglomerative Clustering|agglomerative clustering]]. 

Evaluation of clustering quality is difficult since there are no labels to go off of. Instead other metrics have been proposed such as [[Internal Measures|internal measures]] (Davies-Bouldin index, Bayes information criterion) or [[External Measures|external measures]] (purity, Jaccard index).
## Dimensionality Reduction
Many machine learning problems are high-dimensional, however, this comes with efficiency and overfitting problems. However, we can use techniques to reduce dimensionality while retaining most of the variance in the data. One often-used algorithm is the [[Principle Component Analysis|principle components analysis]].