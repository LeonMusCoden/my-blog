---
lecture: "5"
---
Supervised learning is a type of [[Machine Learning|machine learning]].
The objective is to learn the relationship between input data and a desired output (target labels)
The data contains both inputs $x$ and the corresponding classes $y$. The relationships between the data and labels is explicitly defined, but are too complex to be defined manually. Therefore, they should be learned automatically.

The full dataset is split into train and test set. Each set has labelled sample pairs $(x_1, y_1), \dots, (x_n, y_n)$ with $Y$ number of classes. The ML system is trained to return a decision $f_\theta: x_i \rightarrow y'$. The system is evaluated using the test set by running the test data through the system and comparing the real to the estimated results.

The theoretically optimal classifier is called class posterior $P(y|x) \forall y$. Using it, we can minimise the probability of error by choosing the class that maximises the probability, $y^* = argmax_y P(y|x)$. 

Of course the posterior is purely theoretical and would require infinite data. However, we can try to approximate it using finite data. For that we need to apply the Bayes' rule:
$$
P(y|x) = \frac{P(y,x)}{P(x)} = \frac{P(y) \cdot P(x|y)}{P(x)}
$$
We can simplify this if we only assume 2 classes $y \in \{0,1\}$. Then, the evidence, $P(x)$ marginalises out or is the same for all classes, and the prior, $P(y)$, has no influence on ranking if uniform. That means we can reduce the equation to
$$
P(y|x) \propto P(x|y)/P(x) \quad \text{or} \quad P(y|x) \propto P(x|y) \text{ if } P(y) \text{ is uniform}.
$$
The remaining part of the equation $P(x|y)$ is the likelihood. It can be modelled using different algorithms, for example using [[Naive Bayes]] if we assume $P(x|y)$ to be Gaussian or [[k-Nearest Neighbour|nearest neighbour]] for other distributions. 

Different algorithms can also be combined, which is called [[Classifier Fusion|fusion]].