---
lecture: "5"
---
[[Machine Learning|Machine learning]] results are usually not perfect, therefore, we need to quantify their quality. There are 3 key criteria: Accuracy, speed, and storage requirement. 
## Classification Benchmarks
Imagine an algorithm that outputs a single label for a given image. Then, given a test set, we can determine the accuracy by calculating $1 - errors / n$. 
However, many classification algorithms are multi-label. This is where top-k accuracy comes in. The statistic is expanded to check if the correct label is in the top $k$ results. The limit $k$ is often chose to be $1, 5,$ or $10$. 
## Retrieval Benchmarks
A retrieval algorithm retrieves data given a query. For example, an image library that is searchable via a text query. 
### Precision and recall
We define $X$ to be the set of retrieved documents and $R$ the set of relevant documents. Then, precision is the fraction of relevant instances among the retrieved instances
$$
precision = \frac{|X \cap R|}{|X|},
$$
and recall is the fraction of relevant instances that were retrieved
$$
recall = \frac{|X \cap R|}{|R|}.
$$
Depending on the task one might be more important than the other, therefore, we define the $F$-measure, called harmonic mean, as
$$
F_{\beta} = \frac{(1+\beta^2) \cdot r \cdot p}{\beta^2 \cdot r + p}
$$
With the $F$-measure, recall is $\beta$ times more important than precision. 
### Error-based quality
Outcomes are classified as 
- false positives (FP), called type 1 error,
- true positives (TP),
- false negatives (FN), called type 2 error,
- and true negatives (TN).

Based on those numbers, we calculate the following statistics:

- Error rate: $\frac{FP + FN}{TP + TN + FP + FN}$
- True positive rate (TPR): $\frac{TP}{TP + FN}$
- True negative rate (TNR): $\frac{TN}{TN + FP}$
- False positive rate (FPR): $\frac{FP}{FP + TN}$
- False negative rate (FNR): $\frac{FN}{TP+FN}$
We can also redefine precision and recall as $precision = \frac{TP}{TP + FP}$ and $recall = \frac{TP}{TP + FN}$.
### Confidence-based benchmark
Retrieval systems often compute probabilities for retrieved documents, representing their confidence. This allows us to choose the sensitivity of retrieval by adjusting the threshold $th$ below which results are filtered out. We also get a better impression of system performance and ranked results. 
The quality is measured by varying $th$, such that a desired quality is achieved. 

For example, we can calculate the FPR and TPR at every $th$ and build a curve, called the receiver operating characteristic (ROC). 
![[roc_curve.png]]
The overall performance is measured by calculating the area under curve or AUC. Logically, the AUC can have a value between $1$ and $0.5$.  

We can do the same with precision and recall, but instead of a confidence threshold, we cut off at specific levels of recall. That means as many of the ranked results are included until a specified recall level is reached, then this is set as rank and the precision of the filtered result is calculated. 
![[prec_rec_curve.png]]
The area under the recall-precision (RP) curve is called average precision (AP) and is calculated using $AP = \frac{1}{|R|} \cdot \sum_{rank\,r} prec@r$, where $|R|$ is the total number of relevant items and $prec@r$ is the precision at rank $r$. 
However, a single query is not good enough, therefore, we calculate the mean average precision (MAP), given by $MAP = \frac{1}{Q} \sum_{q=1}^Q AP_q$, where $Q$ is the number of queries. 

The key difference between the ROC and PC curves is that the latter is more useful for needle-in-haystack type problems or where the positive class is more interesting than the negative class. 
### Limitations
Benchmarking specific tasks is easy using the methods above, however, things get complicated when benchmarking entire systems, such as search engines. 

The first issue is the definition of relevance. There is objective relevance, which looks for topical relevance. There is subjective relevance, which judges results according to the user. And there is task-dependent relevance, which measures if a result help the user achieve his/her goal.  

What makes things more complicated is the discrepancy between queries and users' information need. The user is often bad at communicating what he/she actually needs.