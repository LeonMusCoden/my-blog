---
lecture: "5"
---
Generative classifiers learn a model of the joint probability $P(x,y)$, of the inputs $x$ and the label $y$, and make their predictions by using Bayes rules to calculate $p(y|x)$, and then picking the most likely label $y$. 