---
lecture: "6"
---
Support Vector Machines, or SVM for short, is a [[Supervised Learning|supervised learning]] algorithm used for classification and regression. Its core idea is to find the optimal decision boundary (*hyperplane* $\pmb{w}$) that separates data points to different classes with the maximum margin.

This hyperplane as the equation $f(x) = \pmb{w}^T x +b$ and is a line in 2D, a plane in 3D, or a higher-dimensional surface. Margin refers to the distance between the hyperplane and the closest data points.

Every data point $x_i$ has a label $y_i \in \{-1, 1\}$. The hyperplane must for fill these equations:
$$
\begin{align}
\langle w, x_i \rangle \geq 1 \quad &\text{if } y_i = 1 \\
\langle w, x_i \rangle \leq -1 \quad &\text{if } y_i = -1,
\end{align}
$$
where $\langle w, x_i \rangle$ is the inner product between the weight vector $w$ and the feature vector $x_i$. It determines the projection of $x_i$ onto $w$, essentially representing its *distance from the decision boundary*. 
*Safe samples* $x_i$ are ones that are far away from the decision boundary, i.e. $\langle w, x_i \rangle > y_i$, in which case their distance to the decision boundary is at least $1 / ||w||$. *Support vectors* $x_i$ are samples on the margin, i.e. $\langle w, x_i \rangle = y_i$ and have a distance of $1 / ||w||$ to the boundary, resulting in the equation $$1/||w|| = y_i.$$ If we now square both sides, so that $y_i$ is always positive, we get $$1/||w||^2 = y.$$In other words, the size of the margin $y$ is $1 / ||w||^2$. *Maximising that margin is the equivalent to minimising $||w||^2$*. Altogether, a decision boundary $w^*$ that maximises the margin can be computed by solving the following optimisation problem:
$$
w^* = \text{argmin}_{w \in \mathbb{R}^d} ||w||^2, \quad \text{subject to } y_i \langle w, x_i \rangle \geq 1 \;\; \forall i.
$$
The solution $w$ depends only on the support vectors and can be expressed as a linear combination of these training points:
$$
w = \sum_{j=1}^n \alpha_j \cdot x_j,
$$
where $\alpha_j$ are coefficients determined during optimisation.
While it might not look simple, it actually is. The objective function is quadratic, all the constraints are linear, and a globally optimal solution can be computed in $O(n^3)$. 

However, in practice, datasets are often not linearly separable. There are two solutions: Slack variables and kernel functions.
## Slack variables
The key idea is to allow for errors during training in favour of a max margin hyperplane.
![[slack_variables.png]]
Mathematically, we introduce slack variables $\xi_1, \dots, \xi_n$:
$$
w^* = \min_{w,\xi_1,\dots,\xi_n \in \mathbb{R}^+} ||w||^2 + C \sum_i \xi_i \quad \text{subject to } y_i \langle w, x_i \rangle \geq 1 - \xi_i \;\; \forall i,
$$
where $C$ is the so called hyper-parameter, used for balancing. The smaller $C$, the larger the margin at the cost of incorrectly classified training samples. in other words, $C$ controls the cost of misclassified samples. The constraints can be satisfied by making the $\xi_i$ large enough. The target function is still convex, making it a "simple" optimisation.
## Kernel function
For some datasets, slack variables are not enough and we need non-linear decision boundaries. Let's assume we can find a feature transformation $\phi: \mathbb{R}^d \rightarrow \mathbb{R}^m$ for the samples $x_i$, such that they become linearly separable:
![[kernel_function.png]]
We now perform the linear classification on the transformed data $\phi(x_i)$ instead of $x_i$, meaning
$$
w^* = \min_{w \in \mathbb{R}^m,\xi_i \in \mathbb{R}^+} ||w||^2 + C \sum_i \xi_i \quad \text{subject to } y_i \langle w, \phi(x_i) \rangle \geq 1 - \xi_i \;\; \forall i.
$$
That means the maximum-margin solution is now 
$$
w = \sum_{j=1}^n \alpha_j \cdot \phi(x_j).
$$
Lets plug that into the optimisation equation:
$$
w^* = \min_{w \in \mathbb{R}^m,\xi_i \in \mathbb{R}^+} ||\sum_{j=1}^n \alpha_j \cdot \phi(x_ji)||^2 + C \sum_i \xi_i \quad \text{subject to } y_i \langle \sum_{j=1}^n \alpha_j \cdot \phi(x_j), \phi(x_i) \rangle \geq 1 - \xi_i \;\; \forall i.
$$
We can apply the representer theorem to simplify this. The result is
$$
w^* = \min_{w \in \mathbb{R}^m,\xi_i \in \mathbb{R}^+} \sum_{i,j=1}^n \alpha_i \alpha_j \cdot \langle \phi(x_i), \phi(x_j) \rangle + C \sum_i \xi_i \quad \text{subject to } y_i \sum_j \alpha_j \langle \phi(x_j), \phi(x_i) \rangle \geq 1 - \xi_i \; \forall i.
$$
The inner product is again a measure of distance. However, to judge the similarity of two samples $x_i, x_j$, we don't need to transform the first. So, let's replace $\langle \phi(x_i), \phi(x_j) \rangle$ with a so called kernel function $k(x_i, x_j)$, which is a similarity measure between $x_i$ and $x_j$. The equation is now 
$$
w^* = \min_{w \in \mathbb{R}^m,\xi_i \in \mathbb{R}^+} \sum_{i,j=1}^n \alpha_i \alpha_j \cdot k(x_i, x_j) + C \sum_i \xi_i \quad \text{subject to } y_i \sum_j \alpha_j k(x_i, x_j) \geq 1 - \xi_i \; \forall i.
$$
This removes $\phi$ from the equation and means we don't even have to know it.

How do we choose kernel functions? They can be constructed from distance function. That is, if $d(\dots)$ is a distance function, then $e^{-d(\dots)}$ can be used as a kernel function. In practice, common kernel functions include:
1. *Linear kernel*: $k(x, y) = x \cdot y$, which is suitable for linearly separable data
2. *Polynomial kernel*: $k(x, y) = (x \cdot y + c)^d$, where $c$ is a constant and $d$ is the polynomial degree. Useful for non-linear data
3. *Gaussian (RBF) kernel*: $k(x, y) = e^{-\frac{||x - y||^2}{2 \beta^2}}$, where $\beta$ controls the kernel width. Excellent for capturing local relationships. A good $\beta$ is $\text{mean}_{i,j} (||x_i - x_j||^2)$. Frequently used approach for determining $\beta$ and $C$ is [[Grid Search|grid search]]

# Summary
Support Vector Machines were state-of-the-art classifier, particularly in the field of image recognition. Their key advantages are
- The maximum-margin problem can be solved *globally optimally*.
- The number of parameters is independent of the feature dimensionallity. This makes SVMs very suitable classifiers for small, high-dimensional training sets.
- It is quite flexible by incorporating application-specific kernels.
- It has very good empirical results.
Their disadvantages are
- Scalability problems to large training sets
- Limited learning capacity with large number of positive samples
- The choice of kernel function is often made ad hoc
