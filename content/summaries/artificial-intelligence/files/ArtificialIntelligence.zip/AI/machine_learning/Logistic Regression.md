---
lecture: "5"
---
Logistic regression is a [[Discriminative Models||discriminative model]] that classifies based on a threshold $f_\Theta(x) \geq 0.5.$

For example, assume the class labels "Sea Bass" (1) and "Salmon" (0) with the features $x_1$. We can hypothesise that there are some parameters $\Theta = (m,b)$, such that $P(y|x) = f_\Theta(x_1) = mx_1 + b$:
```tikz
\usepackage{pgfplots}
\usetikzlibrary{shapes.geometric}
\begin{document}
	\begin{tikzpicture} 
	\begin{axis}[
		axis lines=middle,
		ymin=-0.2,
		ymax=1.2,
		xmin=-0.5,
		xmax=5,
		xlabel={Lightness \(x_1\)},
		ylabel={},
		xtick=\empty,
		ytick={0, 0.5, 1},
		yticklabels={\textbf{(No) 0}, 0.5, \textbf{(Yes) 1}},
		width=10cm,
		height=6cm,
		every axis x label/.style={at={(ticklabel cs:1.05)}, anchor=west},
		every axis y label/.style={at={(ticklabel cs:1.05)}, anchor=south},
		enlargelimits
	]
		% Decision boundary line 
		\addplot[domain=0:5, thick, green] {0.25 * x} node[pos=0.8, above right] {};
		% Green circles (Yes class) 
		\addplot[only marks, mark=*, mark size=3pt, green] coordinates { (3.5, 1) (4, 1) (4.5, 1) (5, 1) };
		% Red triangles (No class) 
		\addplot[only marks, mark=triangle*, mark size=3pt, red] coordinates { (0.5, 0) (1, 0) (1.5, 0) (1.75, 0) };
		% Dashed line for threshold (horizontal) 
		\addplot[dashed, green] coordinates { (0, 0.5) (2, 0.5) };
		% Dashed line for threshold (vertical) 
		\addplot[dashed, green] coordinates { (2, 0) (2, 0.5) };
	\end{axis}
	\end{tikzpicture}
\end{document}
```

However, this linear regression struggles with outliers and might not capture the distribution well. 

We can improve the regression by replacing the linear hypothesis with a sigmoid function:
$$
f_\Theta (x) = \frac{1}{1+e^{-t}},
$$
where $t = mx + b$. In higher dimensions we replace $m$ with a vector $\pmb{w}$, and the decision boundary becomes a hyperplane. We can omit $b$ using augmented vectors: $x = (x_1, \dots, x_d, 1), w = (w_1, \dots, w_d, b)$.

The parameter vector  $\pmb{w}$ determines the decision function and can be estimated using maximum likelihood. For each weight configuration $\pmb{w}$, we compute the classification loss $\pmb{L}$, also called error. Until $\pmb{L}$ converges, we update the weight configuration according to [[Feedforward Network#Optimiser|gradient descent learning]] and increase $k = k+1$. 

The results of logistic regression are straightforward to interpret and it can be trained quickly. However, the results are non-deterministic and may end up in a local minima. It also has linear decision boundaries, meaning its not effective for complex data distributions. Similar to other [[Machine Learning|ML]] algorithms, it is vulnerable to [[Overfitting|overfitting]].