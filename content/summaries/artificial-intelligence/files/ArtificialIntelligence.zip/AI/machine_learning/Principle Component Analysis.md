---
lecture: "7"
---
is a [[Unsupervised Learning#Dimensionality Reduction|dimensionality reduction]] technique that transforms high-dimensional data $X$ into a lower-dimensional space while retaining as much variance (information) as possible. It achieves this by identifying the directions in which the data varies the most (principal components).

First the data has to be centred around the origin using $\overline{X} = X - \mu$, where $\mu$ is the mean vector of $X$. Now, we need to find each principal component $\pmb{w_i}$ unit vector that is orthogonal to $\pmb{w_1}, \dots, \pmb{w_{i-1}}$. That means 
$$
w_k = \text{arg}\max_{||w|| = 1, \; w \perp w_1, \dots, w_{k-1}} \sum_i (x_i \cdot w)^2.
$$
There are at most $d$ principal components in a $d$-dimensional features space. The principles components form a new feature representation with an orthogonal basis $\mathbb{R}^k$. The components are ordered by their contribution to reconstruct the feature vector back to the original space. 

PCA can for example be used to reduce images of faces. Each pixel $x^{xy}$ of an image is used to construct a high-dimensional feature space $X$. With each principal component, the most common variations of face images slowly transition to noise effects. The final noisy components can be deleted since they don't contain any real information. This reduced dimensional feature space of remaining principal components is called *eigenfaces*.