---
lecture: "5"
---
uses statistical techniques to give computer systems the ability to learn from data, without being explicitly programmed. 
## Learning Setup
Any ML learning system requires the following components:
- Data $\{x_i, y_i\}_{i=1}^N$: The data that we can learn from given as a set of samples (with or without associated labels).
- Model $\hat{y} = f_\theta(x_i)$: A model of how to transform the data as represented by a parameterised function mapping from inputs to outputs.
- Objective / Loss $\theta^* = \min_\theta \mathcal{J}(\theta) = \sum \mathcal{L}(\hat{y_i}, y_i)$: A guiding principle which defines an optimum as given by an objective function quantifying how well the model is doing
- Estimator / Optimiser $\theta^{(t+1)} = \theta^{(t)} - \eta \nabla \mathcal{J}(\theta)$: 
	- An algorithm to find the optimal parameter analytically given a statistical estimator or 
	- adjust the parameters iteratively to optimise a given objective function (see [[Logistic Regression|logistic regression]])
## Learning Paradigms
ML encompasses different learning paradigms based on the nature of the data and the objectives:
- [[Supervised Learning|Supervised learning]]
	- *Objective*: Learn the relationship between input data and a desired output (target labels)
	- *Data*:
		- Contains both inputs $x$ and corresponding labels $c$
		- The relationship between the data and labels is explicitly defined and needs to be learned
	- *Example algorithms*: Decision trees, neural networks, ...
	- *Applications*:
		- Classification: Predicting discrete categories
		- Regression: Predicting continuous values
- **Semi-supervised learning**
	- *Objective*: Learn patterns by combining both labelled and unlabelled data 
	- *Data*: A small portion of the data is labelled while the majority is unlabelled
	- *Applications*:
		- Medical imaging where labels are scarce and expensive to obtain
		- Speech recognition
- **Self-supervised learning**
	- *Objective*: Learn representations of data using pseudo-labels derived from the data itself. Used to prepare data for downstream tasks (e.g., classification) by first learning useful representations
	- *Data*: No explicit labels; instead, pseudo-labels are generated via pretext tasks (predicting a missing part of the input)
	- *Applications*:
		- Natural Language Processing
- [[Unsupervised Learning|Unsupervised learning]]
	- *Objective*: Identify unknown patterns, dependencies, or distributions within the data
	- *Data*:
		- Contains only input data $x$ without corresponding labels
		- Relationships and structures in the data are not predefined
	- *Algorithms*:
		- Clustering (e.g., k-means)
		- Dimensionality reduction 