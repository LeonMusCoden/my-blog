---
lecture: "6"
---

The objective of classifiers is to create a model, which given a minimum amount of data points, is able to produce decisions. However, we often have many data points and features. Ideally, we want a model that can consider all of them. However, that is difficult with simple classifiers and a possible solution to combine multiple methods, such that a better result is achieved.

There are two different combination strategies: Early and late fusion. The former concatenates the features at the start and runs a single classifier. The latter runs classifiers for each feature and then combines the classification results.

