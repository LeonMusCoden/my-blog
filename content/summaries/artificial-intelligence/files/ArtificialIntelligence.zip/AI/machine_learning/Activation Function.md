The **activation function** $\sigma$ is a fundamental component of [[Neural Networks||neural networks]] that introduces non-linearity into the model, allowing it to learn complex representations. 
Each neuron computes a weighted sum of its inputs $z = w^T x + b$, which is then passed through an activation function $\sigma$, such that:
$$
y = \sigma(z).
$$
Different activation functions serve different purposes:

- **Sigmoid Function**: 
  $$
  \sigma(x) = \frac{1}{1 + e^{-x}}
  $$
  The sigmoid function maps inputs to the range $(0,1)$ and is commonly used in binary classification problems. However, it suffers from the [[Feedforward Network#Vanishing gradient problem|vanishing gradient problem]].

- **ReLU (Rectified Linear Unit)**:
  $$
  \text{ReLU}(x) = \max(0, x)
  $$
  ReLU is widely used due to its simplicity and efficiency. It introduces sparsity and helps mitigate the vanishing gradient problem, but it suffers from the issue of *dying neurons* where some neurons never activate.

- **Tanh (Hyperbolic Tangent)**:
  $$
  \tanh(x) = \frac{e^x - e^{-x}}{e^x + e^{-x}}
  $$
  Unlike sigmoid, the tanh function maps inputs to $(-1,1)$, centering data around zero, which can improve training stability.

- **Softmax Function**:
  $$
  \sigma(z_i) = \frac{\exp(z_i)}{\sum_{j=1}^c \exp(z_j)}
  $$
  The softmax function is used in multi-class classification tasks, converting raw network outputs into probabilities where $\sum_i \sigma(z_i) = 1$.