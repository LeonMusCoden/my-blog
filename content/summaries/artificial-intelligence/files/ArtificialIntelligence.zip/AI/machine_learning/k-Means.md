---
lecture: "7"
---
is a [[Unsupervised Learning#Centeroid clustering|centroid clustering]] algorithm for grouping data $\{x_i\} = \{x_1, \dots, x_d\}$ into $k$ clusters based on feature similarity. 

It starts by selecting $k$ initial cluster centroids $\mu_1, \dots, \mu_k$ randomly or through a defined heuristic. Then, each data point is assigned to the nearest cluster centroid $k(i) = \text{argmin}_{k} ||x_i - \mu_k||$ for $i = 1, \dots, n$. Next, compute the new centroids by calculating the mean of all data points assigned to each cluster $\mu_k = \{x_i: k(i) = k \}$ for $k = 1, \dots, k$. Now repeat until there is no flipping of cluster membership. 

k-means is a simple and efficient algorithm and scales well to large datasets. However, it requires specifying $k$ beforehand and the placement of the initial centroids is very import. It may converge to a local minimum or even result in empty clusters, in which case the centroids have to reinitialised. 
Computationally, it requires $O(n \cdot k \cdot numIterations)$ time. 

Choosing the right $k$ is difficult. A high value increases model complexity and a low $k$ increases fitting error. A good strategy is to use a [[Grid Search|grid search]] over final system performance (with e.g. $k=1,3,5,10,\dots$). The performance can be evaluated using [[Internal Measures|internal measures]], such as the Bayes information criterion, or [[External Measures|external measures]], such as purity.

k-Means is a specialisation of a more general learning scheme called [[Expectation Maximisation|expectation maximisation]].