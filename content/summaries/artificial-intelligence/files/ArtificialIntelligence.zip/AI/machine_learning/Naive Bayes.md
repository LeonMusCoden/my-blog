---
lecture: "5"
---
The Naive Bayes is a [[Supervised Learning|supervised learning]] [[Machine Learning|ML]] classifier. It's part of the [[Generative Models|generative classifier]] family.
It represents the likelihood as a class conditional density (CCD). That means having some form of density function for each class $y$.

The most frequently used CCD is the Gaussian distribution. For example, to determine the gender $y = \begin{cases}woman & y = 0 \\ man & y = 1\end{cases}$) of a person by height, we can define $P(y|x)$ as 
$$
P(y|x) \propto P(x|y) = 
\begin{cases}
\mathcal{N}(x;\mu_0,\sigma_0) & y = 0 \\
\mathcal{N}(x;\mu_1,\sigma_a) & y = 1
\end{cases},
$$
assuming that $P(y)$ is uniformly distributed (i.e., same amount of men and women).
Using this, the likelihood for a specific gender can be calculated as follows:
$$
P(y=1|x) = \frac{\mathcal{N}(x;\mu_1,\sigma_1)}{\mathcal{N}(x;\mu_1,\sigma_1) + \mathcal{N}(x;\mu_0,\sigma_0)}
$$
The parameters For mean and variance can be estimated using maximum likelihood, which chooses the parameters that make the observed training data most likely.

The Bayes classifier is fast and easy to interpret, even for high-dimensional data. However, it assumes class independence and only learns simple decision boundaries. Therefore, it's use cases are mostly classification on categorical features. 

As with other ML algorithms, Naive Bayes is also vulnerable to [[Overfitting|overfitting]], especially if it is trained on too few samples or too high dimensions.