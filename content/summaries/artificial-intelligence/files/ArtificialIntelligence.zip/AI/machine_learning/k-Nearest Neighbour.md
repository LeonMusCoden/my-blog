---
lecture: "5"
---

is a [[Supervised Learning|supervised learning]] classifier. It is non-parametric, meaning it does not make any assumptions about the underlying distribution. The idea is to classify points by majority vote - i.e. the class that is most frequently represented around a given data point. 

The algorithm is given a set of labelled training samples $\{x_i, y_i\}$ and and an unknown sample $x$. It works by computing the distance $D(x, x_i)$ of $x$ to every training sample $x_i$, selecting the $k$ closest instances $x_{i1}, \dots, x_{ik}$ and their class labels $y_{i1}, \dots, y_{ik}$, and classifying $x$ according to the majority class of its $k$ neighbours. Mathematically, that means
$$
P(y|x) = \frac{1}{k} \sum_{j=1}^{k} \delta(y_{ij},y), \quad \text{where } \delta = \begin{cases} 1 & \text{if } y_{ij} = y \\ 0 & \text{if } y_{ij} \neq y \end{cases}\enspace.
$$
k-Nearest Neighbours is therefore simple to implement and flexible, by choosing a different method of calculating distance. However, it is computationally expensive as every distance has to be calculated. Depending on the distance calculation, it can also be sensitive to outliers.

Choosing the right $k$ is also important. A low $k$ results in high variance and a high $k$ in over-smoothing. A good compromise is $k = \sqrt{n}$, where $n$ is the number of labelled points. 
## Distance calculation
The question is how to calculate the $k$ neighbours. There are multiple algorithms:
### Euclidean
Euclidean distance, also called L2-norm, is the straight-line distance between two points in Euclidean space, calculated as 
$$
D(x, x_i) = \sqrt{\sum_{i=1}^n (x - x_i)^2}.
$$
It is used in the context of continuous variables, where the differences between the numeric values are meaningful. 

Squaring differences magnifies large deviations, and makes it sensitive to outliers. It is therefore not robust. However, it produces a unique minimum distance.
### Manhatten
Manhatten distance, also called L1-norm, is the sum of the absolute differences between corresponding coordinates of two points:
$$
D(x, x_i) = \sum_{i=1}^n |x - x_i|
$$
It is used for binary or encoded variables, where individual changes are of equal importance. Unlike Euclidean distance, it measures the path length along grid-like movements (similar to walking in Manhatten). 

It is less sensitive to outliers and therefore robust. However, it can produce ties in distances.
### Hamming
Hamming distance is the number of positions at which corresponding elements in two sequences differ:
$$
D(x, x_i) = \sum_{i=1}^n \delta(x, x_i), \quad \text{where } \delta = \begin{cases}0 & \text{if } x_i = x \\ 1 & \text{if } x_i \neq x \end{cases}
$$
It is used for categorical variables or sequences, such as text or DNA. 
