---
lecture: "5"
---
Overfitting is a fundamental challenge in [[Machine Learning|machine learning]]. It occurs when an algorithm fits too closely or even exactly to its training data, resulting in a model that can't make accurate predictions or conclusion from any data other than the training data. 

It defeats the purpose of learning from data, which is generalisation. 

It often happens when the model is too complex and starts to learn the noise in the data. Other causes include too few training samples or too many redundant features. 

A symptom of overfitting is low error rates and high variance in the train data or low error rates in train data, but high error in test data.