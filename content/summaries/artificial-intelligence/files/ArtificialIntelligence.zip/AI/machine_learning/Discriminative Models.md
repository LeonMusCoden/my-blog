---
lecture: "5"
---
Compared to [[Generative Models|generative models]], discriminative models directly estimate $P(y | x)$. These models focus on learning the decision boundary that separates the classes. This is achieved by optimising a function $P(y|x) = f_\Theta(x)$, where $\Theta$ are the parameters. 